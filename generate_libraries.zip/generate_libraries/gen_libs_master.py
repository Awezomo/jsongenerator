# Description: This file is the master file for the generation of data for the JSON files. It calls the respective functions from the other files to generate the data for the JSON files.  
from . import generate_persons,generate_badges,generate_activities,generate_organisations,generate_goals

def generate_data(jsonType, selected_attributes, uploadedData, num_records=1):
    if uploadedData is None:
        standard_attributes = {}

        for attribute in selected_attributes:
            standard_attributes[attribute] = None
        
        for _ in range(num_records):
            record = {}
        
            if standard_attributes:
                if jsonType == 'persons':
                    generated_data = generate_persons.generate_json_data(standard_attributes.keys(), 1)[0]
                elif jsonType == 'badges':
                    generated_data = generate_badges(selected_attributes, uploadedData, num_records)
                elif jsonType == 'activities':
                    generated_data = generate_activities(selected_attributes, uploadedData, num_records)
                elif jsonType == 'organisations':
                    generated_data = generate_organisations(selected_attributes, uploadedData, num_records)
                elif jsonType == 'goals':
                    generated_data = generate_goals(selected_attributes, uploadedData, num_records)
                else:
                    raise ValueError(f"Invalid JSON type: {jsonType}")
                
                record.update(generated_data)
        
            results.append(record)
    else:
        print("Uploaded data found")
        results = generate_persons.generate_data_mf(uploadedData, num_records)

    if results:
        return results
    else:
        return {}
    