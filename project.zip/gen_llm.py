import json
from llamaapi import LlamaAPI

# Initialize the SDK
llama = LlamaAPI("LL-6g6coRla8CDEm952LIYa3fESYwW9y9b2VLvrTvzhBa0KtbVl8qMALkIxCEZgpQ0x")

def generate_data(jsonType, selected_attributes, uploadedData, num_records=1):

    if jsonType == 'persons':
        return generate_persons(selected_attributes, uploadedData, num_records)
    elif jsonType == 'badges':
        return generate_badges(selected_attributes, uploadedData, num_records)
    elif jsonType == 'activities':
        return generate_activities(selected_attributes, uploadedData, num_records)
    elif jsonType == 'organisations':
        return generate_organisations(selected_attributes, uploadedData, num_records)
    elif jsonType == 'goals':
        return generate_goals(selected_attributes, uploadedData, num_records)
    else:
        return []
    

def generate_persons(selected_attributes, uploadedData, num_records):
    # Build the API request
    # Build the Request
    api_request_json = {
    'model': 'llama-13b-chat',
    'functions': [
        {
            "name": "get_flight_info",
            "description": "Get flight information between two locations",
            "parameters": {
                "type": "object",
                "properties": {
                    "loc_origin": {
                        "type": "string",
                        "description": "The departure airport, e.g. DUS"
                    },
                    "loc_destination": {
                        "type": "string",
                        "description": "The destination airport, e.g. HAM"
                    }
                },
            "required": ["loc_origin", "loc_destination"]
            }
        }
    ],
    'function_call': {'name': 'get_flight_info'},
    'messages': [
        {'role': 'user', 'content': "When's the next flight from Amsterdam to New York?"}],
    }

    # Execute the Request
    response = llama.run(api_request_json)
    response = response.json()
    print(json.dumps(response, indent=2))
    return None


def generate_badges(selected_attributes, uploadedData, num_records):
           pass
def generate_activities(selected_attributes, uploadedData, num_records):
           pass
def generate_organisations(selected_attributes, uploadedData, num_records):
            pass

def generate_goals(selected_attributes, uploadedData, num_records):
           pass