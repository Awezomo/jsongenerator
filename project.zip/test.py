import json
import random
import torch
from transformers import GPTNeoForCausalLM, GPT2Tokenizer, set_seed, pipeline

# Load your fine-tuned model and tokenizer
model_name = "gpt_neo_finetuned"  # Replace with the path to your fine-tuned model
tokenizer = GPT2Tokenizer.from_pretrained(model_name)
model = GPTNeoForCausalLM.from_pretrained(model_name)

# Set the device to GPU if available
device = "cuda" if torch.cuda.is_available() else "cpu"
model.to(device)

# Set the generator pipeline
generator = pipeline('text-generation', model=model, tokenizer=tokenizer, device=device)

def generate_person_data():
    # Set a random seed for each generation for variability
    random_seed = random.randint(0, 10000)
    set_seed(random_seed)
    
    prompt = """Generate a JSON object with the following properties:
    "userName": {
                            "type": "string",
                            "description": "The username of the person, for a volunteering platform",
                        },
                        "password": {
                            "type": "string",
                            "description": "a password one person would chose",
                        },
                        "email": {
                            "type": "string",
                            "description": "the mail address of the person, most of the users are from austria, so use reasonable domains. make sure the address is not usually using another name than the first and last names generated ",
                        },
                        "firstName": {
                            "type": "string",
                            "description": "the first name of the person. most of the users are from austria, so use reasonable names",
                        },
                        "lastName": {
                            "type": "string",
                            "description": "the last name of the person. most of the users are from austria, so use reasonable names",
                        },
                        "birthDate": {
                            "type": "string",
                            "description": "the birth date of the person",
                        }

    
    JSON object:
    """
    
    generated_text = generator(prompt, max_new_tokens=200, num_return_sequences=1)[0]['generated_text']

    print(generated_text)
    # Extract JSON part from the generated text
    start_idx = generated_text.find('{')
    end_idx = generated_text.rfind('}') + 1
    json_text = generated_text[start_idx:end_idx]
    
    # Load the text as JSON
    try:
        person_data = json.loads(json_text)
        
        # Validate and clean the data
        if not isinstance(person_data, dict):
            return {}
        
        expected_keys = {"firstName", "lastName", "birthDate"}
        if not expected_keys.issubset(person_data.keys()):
            return {}
        
        # Optionally, you can add more validation here (e.g., regex for birthDate format)
        
    except json.JSONDecodeError:
        # Handle the case where the generated text is not a valid JSON
        person_data = {}
    
    return person_data

# Generate multiple person data
persons = [generate_person_data() for _ in range(10)]

# Output the generated data
print(json.dumps(persons, indent=2))