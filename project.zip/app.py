import datetime
from flask import Flask, render_template, request, jsonify, send_file, abort, redirect, url_for
import json
from io import BytesIO
import matplotlib
# Use the Agg backend
matplotlib.use('agg')
import matplotlib.pyplot as plt
import io
import base64

import gen_libs
import gen_llm

app = Flask(__name__)


def generate_data(jsonType, uploadedData, attributes, method, num_records):
    results = []
    if method == 'python_libraries':
        if uploadedData is None:
            print("No uploaded data"+str(attributes))
            standard_attributes = {}

            for attribute in attributes:
                standard_attributes[attribute] = None
            
            for _ in range(num_records):
                record = {}
            
                if standard_attributes:
                    generated_data = gen_libs.generate_json_data(standard_attributes.keys(), 1)[0]
                    record.update(generated_data)
            
                results.append(record)
        else:
            print("Uploaded data found")
            results = gen_libs.generate_data_mf(uploadedData, num_records)

        if results:
            return results
        else:
            return {}
    
    if method == 'llama':
        return gen_llm.generate_data(jsonType, attributes, uploadedData, num_records)

def visualize_data(data):
    # Placeholder for visualization logic
    x = [1, 2, 3, 4, 5]
    y = [10, 20, 15, 25, 30]

    # Create a plot
    plt.plot(x, y)
    plt.xlabel('X-axis')
    plt.ylabel('Y-axis')
    plt.title('Sample Plot')

    # Save the plot to a BytesIO object
    img = io.BytesIO()
    plt.savefig(img, format='png')
    img.seek(0)

    # Encode the plot image as base64 string
    plot_base64 = base64.b64encode(img.getvalue()).decode()

    # Construct the HTML to display the plot image
    visualization_html = f'<img src="data:image/png;base64,{plot_base64}" alt="Sample Plot">'

    # Clear the plot to release resources
    plt.clf()

    return visualization_html

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/favicon.ico')
def favicon():
    return redirect(url_for('static', filename='favicon.ico'), code=301)

@app.route('/<json_type>')
def json_type(json_type):
    return render_template('{}.html'.format(json_type))

def preprocess_json(json_data):
    # Remove line breaks within string values
    json_data = json_data.replace('\n', ' ').replace('\r', '')
    return json_data

@app.route('/generate', methods=['POST'])
def generate():
    # Get JSON type, attributes, and generation method from the form
    json_type = request.form['jsonType']
    selected_attributes = request.form.getlist('attribute')
    generation_method = request.form['generationMethod']
    uploaded_file = request.files['file']  # Access the uploaded file
    num_records = int(request.form.get('numRecords', 1)) 

    # Check if a file was uploaded
    if uploaded_file.filename != '':
        # Read the contents of the uploaded file
        file_contents = uploaded_file.read().decode('utf-8')  # Decode bytes to string
        # Preprocess the file contents
        file_contents = preprocess_json(file_contents)
        # Process the file_contents as needed
        # For example, you can parse the contents as JSON data
        try:
            uploaded_data = json.loads(file_contents)
            # Process the uploaded data as needed
        except json.JSONDecodeError as e:
            # Handle JSON decoding error
            return jsonify({'error': 'Invalid JSON file'}), 400
    else:
        uploaded_data = None

    # Generate JSON data based on selected attributes and method
    data = generate_data(json_type, uploaded_data, selected_attributes, generation_method, num_records)

    # Convert data to JSON format
    json_data = json.dumps(data, indent=4).encode('utf-8').decode('unicode_escape')

    # Generate visualization HTML
    visualization_html = visualize_data(data)

    # Render results page with generated JSON data and visualization
    return render_template('results.html', json_data=json_data, json_type=json_type, visualization_html=visualization_html)

@app.route('/download_json', methods=['POST'])
def download_json():
    json_data = request.form.get('json_data')
    json_type = request.form.get('json_type')

    if json_data is None:
        abort(400, "No JSON data provided")

    fake_file = BytesIO(json_data.encode())
    current_datetime = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    file_name = f"{json_type}_{current_datetime}.json"

    return send_file(fake_file, as_attachment=True, download_name=file_name)

if __name__ == '__main__':
    app.run(debug=True)
